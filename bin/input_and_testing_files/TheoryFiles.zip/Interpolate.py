#!/usr/bin/env python

import numpy as np
from EnsembleSAXS import *


scatfile = np.genfromtxt("filelist.txt",usecols=0,dtype=str)
q,i,err = np.genfromtxt("SAXS_data.dat",unpack=True,dtype=float)

for profile in scatfile:
    qt,it = np.genfromtxt(profile,usecols=(0,1),unpack=True,dtype=float)
    newi  = interpolate(q,qt,it)
    outf  = open("interpolated_"+profile,'w')
    for qidx in range(len(q)):
        outf.write(str(q[qidx])+'\t'+str(newi[qidx])+'\n')
    outf.close()
